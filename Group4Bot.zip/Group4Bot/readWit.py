from witA import Wit
import random

access_token = "BKXQLOFJUM5A7EEBLOGEBNTEQQVQSRCZ"
client = Wit(access_token = access_token)

def wit_response(message_text,s_id):
	response = client.message(msg=message_text, context={'session_id':s_id})
	return response

def first_entity_value(entities, entity):
    if entity not in entities:
        return None
    val = entities[entity][0]['value']
    if not val:
        return None
    return val['value'] if isinstance(val, dict) else val


def get_news_elements(response,fb_id):
    entities = response['entities']
    greetings = first_entity_value(entities,'greetings')
    location = first_entity_value(entities,'location')
    thanks = first_entity_value(entities,'thanks')
    bye = first_entity_value(entities,'bye')
    
    if greetings:
        text = "Hello"
    if location:
        text = location
    if thanks:
        text="It's my pleasure.Thank you for use our service."
    if bye:
        text = "Hope see you again soon,bye"

    else:
        text = "Hello, May I help you ? "

    return text