from __future__ import absolute_import, print_function

from flask import Flask

raise ImportError()

testapp = Flask('testapp')
