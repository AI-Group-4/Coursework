import os,sys
from flask import Flask, request
from readWit import wit_response,get_news_elements
import requests




app = Flask(__name__)
PAGE_ACCESS_TOKEN_1 = 'EAALD6IN7qOIBAFWID9SkJknV625A71VRBgFIcI6nyXNKRiT6qZCnDfebvBpKZBGuNnfb8iwz383l0mM0r5Ql6ZBTiXcFncHCZBdK7TU0wmXpS7FgJobDwLpndiawD7nrz4ZBjgQHmxJa1sIFRUhaligZCxdfzGEAwi1FAdfpoaZBqKiU3nV0ufxuZCgSABQSZB8oZD'
VERIFICATION_TOKEN = "helloRailinformation"


@app.route('/', methods=['GET'])
def verify():
	if request.args.get("hub.mode") == "subscribe" and request.args.get("hub.challenge"):
		if not request.args.get("hub.verify_token") == VERIFICATION_TOKEN:
			return "Verification token mismatch", 403
		return request.args["hub.challenge"], 200
	return "Hello world", 200

@app.route('/', methods=['POST'])
def webhook():
    data = request.get_json()
    if data['object']=='page':
        for entry in data['entry']:
            for msging_event in entry['messaging']:
                s_id = msging_event['sender']['id']
                if msging_event.get('message'):
                    if 'text' in msging_event['message']:
                        msg_text = msging_event['message']['text']
                        newRply = get_news_elements(wit_response(msg_text,s_id),s_id)
                    else:
                        msg_text = 'no text'
                    reply(s_id,newRply)
  
    return "ok",200


def log(message):
    print(message)
    
    sys.stdout.flush()

def reply(user_id, msg):
    data = {
        "recipient": {"id": user_id},
        "message": {"text": msg}
    }
    resp = requests.post("https://graph.facebook.com/v2.6/me/messages?access_token=" + PAGE_ACCESS_TOKEN_1, json=data)
    print(resp.content)

if __name__ == "__main__":
	app.run(debug =True,port=3000)